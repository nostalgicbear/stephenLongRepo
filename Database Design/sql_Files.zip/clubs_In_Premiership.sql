select * from club where league = 'Premiership'
order by clubName
