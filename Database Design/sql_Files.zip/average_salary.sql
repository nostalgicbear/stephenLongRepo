# calculates the average salary among all players
SELECT AVG(salary) as averageSalary from contract
