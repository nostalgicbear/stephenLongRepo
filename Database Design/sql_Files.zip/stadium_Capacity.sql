select * from stadium where capacity > 30000 and capacity < 70000
